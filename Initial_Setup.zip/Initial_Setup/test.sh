cd NodeJS/
rm -rf ./test-report.xml && CI=true npm test;
cd ..