const e = require("express");
const express = require("express");
const SellBuy =require("../mongoose/models/sellBuy")

// setting up the router

const sellAndBuyRouter = new express.Router();

// code goes here for routes


// exporting the router

module.exports = sellAndBuyRouter;


