cd NodeJS
rm calculate-score.js
npm install
echo "Installations are done"
cd ..